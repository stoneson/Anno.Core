﻿using System;


namespace Anno.Test
{
    class Program
    {
       
        static void Main(string[] args)
        {
            //LruCacheTest2.Handle();
            //LruCacheTest.Handle();
            AnnoRpcTest.Handle();
            Console.ReadLine();
        }
    }
}
