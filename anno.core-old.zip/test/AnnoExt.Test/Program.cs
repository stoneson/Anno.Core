﻿using System;


namespace Anno.Test
{
    class Program
    {
       
        static void Main(string[] args)
        {
            //LruCacheTest2.Handle();
            //LruCacheTest.Handle();

            //AnnoRpcTest.Handle();

            //Tx1ServiceTest.Handle();
            //Tx2ServiceTest.Handle();
            //Tx3ServiceTest.Handle();
#if NETFRAMEWORK
            WCFTest.Handle();
#endif
            Console.ReadLine();
        }
    }
}
