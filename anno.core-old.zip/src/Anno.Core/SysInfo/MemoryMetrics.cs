﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Anno.EngineData.SysInfo
{
    public class MemoryMetrics
    {
        public double Total;
        public double Used;
        public double Free;
    }
}
