﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Anno.Loader
{
    /// <summary>
    /// 指定将创建服务的单个实例
    /// </summary>
    public class SingletonAttribute : System.Attribute
    {
    }
}
