﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Anno.Loader
{
    /// <summary>
    /// 指定服务的新实例将在每次请求时创建。  
    /// </summary>
    public class TransientAttribute : System.Attribute
    {
    }
}
