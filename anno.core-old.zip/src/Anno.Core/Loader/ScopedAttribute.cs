﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Anno.Loader
{
    /// <summary>
    /// 指定将为每个范围创建服务的新实例。 
    /// </summary>
    public class ScopedAttribute : System.Attribute
    {
    }
}
