﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Anno.Loader
{
    /// <summary>
    /// 自动扫描不注入IOC容器
    /// </summary>
    public class NotInInjectAttribute : System.Attribute
    {
    }
}
