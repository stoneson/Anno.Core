﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Anno.EngineData
{
    /// <summary>
    /// FromBody 标记
    /// </summary>
    public class FromBodyAttribute : Attribute
    {
    }
}
