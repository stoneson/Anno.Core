﻿using SoEasy.Application.Po;
using System;
using System.Collections.Generic;
using System.Text;

namespace SoEasy.Application.Repositories
{
    public class UserRepository : BaseRepository<UserEntity>, IBaseRepository<UserEntity>
    {
    }
}
