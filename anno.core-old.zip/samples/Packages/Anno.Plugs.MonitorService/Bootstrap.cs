﻿using Anno.EngineData;
using System;

namespace Anno.Plugs.MonitorService
{
    public class Bootstrap : IPlugsConfigurationBootstrap
    {
        public void ConfigurationBootstrap()
        {

        }

        public void PreConfigurationBootstrap()
        {

        }
    }
}
