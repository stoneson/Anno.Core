﻿using System;

namespace Anno.EventBus.Model.Config.Subscribe
{
    public interface ISubscribeConfig
    {
        bool Check();
    }
}
