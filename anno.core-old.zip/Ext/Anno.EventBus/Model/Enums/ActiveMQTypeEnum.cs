﻿using System;

namespace Anno.EventBus.Model.Enums
{
    /// <summary>
    /// 
    /// </summary>
    public enum ActiveMQTypeEnum
    {

        Queue , Topic

    }
}
